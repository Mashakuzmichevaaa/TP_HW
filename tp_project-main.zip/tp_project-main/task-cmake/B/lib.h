char Check_b();
