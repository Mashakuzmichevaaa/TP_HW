#include "lib.h"

char Check_b(){
	return 'b';
}
