#include "A/index.h"
#include "B/lib.h"
#include "gtest/gtest.h"

TEST(LibTEST, A_dir){
    ASSERT_EQ('a', Check_a());
}


TEST(LibTEST, B_dir){
    ASSERT_EQ('b', Check_b());
}

