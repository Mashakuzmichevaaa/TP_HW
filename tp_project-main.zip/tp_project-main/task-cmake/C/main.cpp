#include "main.h"

using std::cout;
char Check_c(){
	return 'c';
}
int main(){
	cout << Check_a() << '\n';
	cout << Check_b() << '\n';
	cout << Check_c() << '\n';
}
