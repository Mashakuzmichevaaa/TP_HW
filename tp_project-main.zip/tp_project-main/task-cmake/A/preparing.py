file = open('index.h','w')
text ="""
char Check_a(){
	return 'a';
}
"""
file.write(text + '\n')
file.close
