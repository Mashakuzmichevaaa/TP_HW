Mariya Kuzmicheva, Б05-225
