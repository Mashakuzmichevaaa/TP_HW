#!/bin/bash

PrintName() {
	IFS="
"
	pth="$(pwd)"
	cd $1
	#copying files with all subdirs with searching extention
	for file in $(find -name "*.$2" | cut -sd / -f 2-)
	do
		cp --parents $file $3
	done
	cd $pth
}

counter=0
declare -a compiler
#reading flags
while [ -n "$1" ]
do
	case "$1" in
		-s | --source)
			path=$2;;
		-a | --archive)
			archive=$2;;
		-c | --compiler)
			compiler[$counter]=$2
			((counter++));;
		--)shift 2
		break;;
	esac
	shift 2
done
mkdir $archive
way_to_dir="$(pwd)"/"$archive"

for ((i=0; i<$counter; i++))
do
	#parsing extentions and copying files with searching extentions in created file 
	IFS="="
	for extens in ${compiler[$i]}
	do
		PrintName "$path" "$extens" "$way_to_dir"
		compiler_name=$extens
	done
	#removing files with the last one, cause it isn't searching one, it is compiler
	IFS="
"	
	for file in $(find $way_to_dir -type f -name "*.$compiler_name")
	do
		rm $file
	done
	#copied programs should be compiled in the created dir, than this progss would be removed, and only executable files would exist
	IFS="="
	for extens in ${compiler[$i]}
	do
		IFS="
"
		for file in $(find $way_to_dir -type f -name "*.$extens")
		do
			f=${file%.*}
			"$compiler_name" "-o" "$f.exe" "$file"
			rm $file
		done
	done
done
tar -czpf $archive.tar.gz $archive
rm -r $archive
echo "complete"
