class ClassLib {
 public:
    void Set(int value);
    int Get() const;
 private:
    int x_;
};
